sudo apt install python3.8
pip3 install bcoding

echo -e "Requiremnts installed"
